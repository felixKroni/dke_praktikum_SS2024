from app.controllers.baseController import BaseController


class AbschnittController(BaseController):
    def __init__(self, session):
        super().__init__(session)